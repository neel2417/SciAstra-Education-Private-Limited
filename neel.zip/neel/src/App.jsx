import React from 'react';

class SciAstraHomepage extends React.Component {
  render() {
    return (
      <div>
        <nav>
          <ul>
            <li><button type="submit"><a href="index.html">Home</a></button></li>
            <li><button type="submit"><a href="about.html">About</a></button></li>
            <li><button type="submit"><a href="blog.html">Blog</a></button></li>
            <li><button type="submit"><a href="contact.html">Contact</a></button></li>
          </ul>
        </nav>

        {/* Homepage */}
        <section id="home" style={{height: "100vh", backgroundImage: "url(https://www.bing.com/th/id/OGC.9ae0aa2ff25aa43147538ac2a9f3137f?pid=1.7&rurl=http%3a%2f%2fblogs.studentlife.utoronto.ca%2flifeatuoft%2ffiles%2f2018%2f09%2fscientists_2.gif&ehk=AOSzz4OB6zYps%2bMAIq3W%2fdxjSRgu9ncE%2fUOeglPgHWw%3d)", backgroundSize: "cover", backgroundPosition: "auto", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", textAlign: "center", padding: "10px", color: "rgb(28, 21, 50)" }}>
          <h1 style={{fontSize: "5rem", marginBottom: 0}}>Welcome to SciAstra</h1>
          <h2 style={{fontSize: "1.5rem", marginTop: 0}}>Explore the fascinating world of science with us!</h2>
        </section>

        {/* Sign-up Page */}
        <section id="signup" style={{height: "100vh", backgroundColor: "#f2f2f2", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", textAlign: "center", padding: "10px"}}>
          <h2>Sign-up to SciAstra</h2>
          <form style={{width: "50%", backgroundColor: "white", padding: "20px", borderRadius: "5px", boxShadow: "0 0 5px grey"}}>
            <label htmlFor="name">Name</label>
            <input type="text" id="name" name="name" required />

            <label htmlFor="phone">Phone Number (with country code)</label>
            <input type="tel" id="phone" name="phone" required />

            <label htmlFor="email">Email Address</label>
            <input type="email" id="email" name="email" required />

            <button type="submit" style={{backgroundColor: "#4CAF50", color: "white", padding: "12px 20px", border: "none", borderRadius: "4px", cursor: "pointer", marginTop: "10px"}}>Submit</button>
          </form>
        </section>
      </div>
    );
  }
}

export default SciAstraHomepage;
